﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class ViewRubrics : UserControl
    {
        public ViewRubrics()
        {
            InitializeComponent();
        }

        private void allradio_btn_CheckedChanged(object sender, EventArgs e)
        {
            LoadFromDataBase();
        }
        private void LoadFromDataBase()
        {
            // filling the data in the grid
            this.viewPnlGrid.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT Details,CloId FROM Rubric R JOIN Clo C on C.Id = R.CloId ";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            this.viewPnlGrid.DataSource = dt;
            //updateRubericGV.AllowUserToAddRows= false;

            // filling the combobox


        }
    }
}
