﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class DeleteStudents : UserControl
    {
        public DeleteStudents()
        {
            InitializeComponent();
            showStudents();
        }

        public void showStudents()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT S.Id,S.RegistrationNumber AS Registration, CONCAT(S.FirstName,' ',S.LastName) AS Name,S.Contact, Lu.Name AS Status FROM Student S JOIN Lookup Lu ON Lu.LookupID = S.Status AND Lu.Name = 'Active' ";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DeleteGrid.DataSource = dt;
        }


        private void searchLabel_Click(object sender, EventArgs e)
        {

        }

        private void Load_btn_Click(object sender, EventArgs e)
        {
            string userInput = Search_txtbx.Text;
            if (userInput.Length != 0)
            {
                try
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("SELECT S.Id,S.RegistrationNumber AS Registration, CONCAT(S.FirstName,' ',S.LastName) AS Name,S.Contact, Lu.Name AS Status FROM Student S JOIN Lookup Lu ON Lu.LookupID = S.Status AND Lu.Name = 'Active'  WHERE RegistrationNumber = @userInput", con);
                    cmd.Parameters.AddWithValue("@userInput", userInput);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    DeleteGrid.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                showStudents();
            }
            Search_txtbx.Text = string.Empty;
        }

        private void Delete_btn_Click(object sender, EventArgs e)
        {
            int selectedIndex = DeleteGrid.SelectedCells[0].RowIndex;
            string selectedID = DeleteGrid.Rows[selectedIndex].Cells[0].Value.ToString();
            var con = Configuration.getInstance().getConnection();
            string query = "UPDATE Student SET Status = 6 WHERE Id = @id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", selectedID);
            cmd.ExecuteNonQuery();


            showStudents();
        }

        private void Search_txtbx_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
