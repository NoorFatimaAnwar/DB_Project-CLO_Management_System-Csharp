﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class DeleteCloPnl : UserControl
    {
        public DeleteCloPnl()
        {
            InitializeComponent();
            ShowAllClos();


        }
        private void ShowAllClos()
        {
            this.DeleteCloGrid.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Clo";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            this.DeleteCloGrid.DataSource = dt;
            this.DeleteCloGrid.AllowUserToAddRows = false;

            cmd.ExecuteNonQuery();
        }
        private void Delete_btn_Click(object sender, EventArgs e)
        {
      
            try
            {
                int selectedIndex = DeleteCloGrid.SelectedCells[0].RowIndex;
                string selectedID = DeleteCloGrid.Rows[selectedIndex].Cells[0].Value.ToString();
                var con = Configuration.getInstance().getConnection();
                string query = " DELETE FROM StudentResult WHERE RubricMeasurementId IN (SELECT Id FROM RubricLevel WHERE RubricId IN (SELECT Id FROM Rubric WHERE CloId = @id)); DELETE FROM AssessmentComponent WHERE RubricId IN(SELECT Id FROM Rubric WHERE CloId = @id );         DELETE FROM RubricLevel WHERE RubricId IN(SELECT Id FROM Rubric WHERE CloId = @id);     DELETE FROM Rubric WHERE CloId = @id;    DELETE FROM Clo WHERE Id = @id";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", selectedID);
                cmd.ExecuteNonQuery();


                ShowAllClos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Load_btn_Click(object sender, EventArgs e)
        {
            string userInput = Search_txtbx.Text;
            if (userInput.Length != 0)
            {
                try
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM  Clo WHere  Name = @userInput", con);
                    cmd.Parameters.AddWithValue("@userInput", userInput);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    DeleteCloGrid.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                ShowAllClos();
            }
            Search_txtbx.Text = string.Empty;
        }

        private void DeleteCloPnl_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DeleteCloGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
