﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class RubricLevel : UserControl
    {
        public RubricLevel()
        {
            InitializeComponent();
            LoadRubricLevelsFromDataBase();
            MapRubericsToComboBox();
        }
        private void LoadRubricLevelsFromDataBase()
        {
            
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT  R.Id AS RubericID, RL.Details,RL.MeasurementLevel AS Marks, R.CloID AS MappedCLO FROM RubricLevel RL JOIN Rubric R ON R.Id = RL.RubricId";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            this.Rubriclvl_GV.DataSource = dt;
            this.Rubriclvl_GV.AllowUserToAddRows = false;
        }

        private void MapRubericsToComboBox()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT CONCAT(R.Id,'-',R.Details) FROM Rubric R";
            SqlCommand cmd = new SqlCommand(query, con);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    rubric_Combo.Items.Add(reader.GetString(0));
                }
                rubric_Combo.SelectedIndex = 0;
            }
        }

        private bool CheckRubericCount(int rubricId)
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT COUNT(*) FROM RubricLevel WHERE RubricId=@rubricId";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@rubricID", rubricId);

            // Our rubric has maximum four levels, this zero-based parameter in if
            // statement verifies that the count of the rubric levels being added were three.

            if (((int)cmd.ExecuteScalar() <= 3)) return true;

            //MessageBox.Show(cmd.ExecuteScalar().ToString());

            throw new Exception("Rubric Levels being added exceeded Max. Count. Try Again");
        }

        private void AddRubericLevelIntoDatabase(int rubricID, int measure, string details)
        {
            var con = Configuration.getInstance().getConnection();
            string query = "INSERT INTO RubricLevel(RubricId,Details,MeasurementLevel) VALUES (@rid,@det,@measurelevel)";
            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@rid", rubricID);
            cmd.Parameters.AddWithValue("@det", details);
            cmd.Parameters.AddWithValue("@measurelevel", measure);

            cmd.ExecuteNonQuery();
        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (rubric_Combo.Text == null) throw new Exception("Select a rubric to be associated with");

                if (int.Parse(Marks.Value.ToString()) < 0) throw new ArgumentOutOfRangeException("Invalid Marks selected.");

                if (Details_txt.Text == null) throw new ArgumentOutOfRangeException("Set Details of the level.");

                int rubericID = int.Parse(rubric_Combo.Text[0].ToString());
                int measure = int.Parse(Marks.Value.ToString());
                string details = Details_txt.Text;
                if (details.Contains(',')) throw new Exception("Can't use comma delimiter. Use ; instead.");

                CheckRubericCount(rubericID);

                AddRubericLevelIntoDatabase(measure: measure, rubricID: rubericID, details: details);
                LoadRubricLevelsFromDataBase();
                MessageBox.Show("Added Sucessfully");
                Details_txt.Text = string.Empty;
                Marks.Value = 0;
                rubric_Combo.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Rubriclvl_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Marks_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
