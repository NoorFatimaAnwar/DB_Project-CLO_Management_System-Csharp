﻿namespace midPro1
{
    partial class DeleteCloPnl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Search_txtbx = new System.Windows.Forms.TextBox();
            this.searchLabel = new System.Windows.Forms.Label();
            this.Load_btn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Delete_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.DeleteCloGrid = new System.Windows.Forms.DataGridView();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeleteCloGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // Search_txtbx
            // 
            this.Search_txtbx.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Search_txtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search_txtbx.Location = new System.Drawing.Point(192, 21);
            this.Search_txtbx.Name = "Search_txtbx";
            this.Search_txtbx.Size = new System.Drawing.Size(264, 22);
            this.Search_txtbx.TabIndex = 40;
            // 
            // searchLabel
            // 
            this.searchLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.searchLabel.AutoSize = true;
            this.searchLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchLabel.Location = new System.Drawing.Point(93, 28);
            this.searchLabel.Name = "searchLabel";
            this.searchLabel.Size = new System.Drawing.Size(93, 15);
            this.searchLabel.TabIndex = 39;
            this.searchLabel.Text = "Search by Name";
            // 
            // Load_btn
            // 
            this.Load_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Load_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Load_btn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Load_btn.Location = new System.Drawing.Point(462, 19);
            this.Load_btn.Name = "Load_btn";
            this.Load_btn.Size = new System.Drawing.Size(116, 23);
            this.Load_btn.TabIndex = 38;
            this.Load_btn.Text = "Load Database";
            this.Load_btn.UseVisualStyleBackColor = true;
            this.Load_btn.Click += new System.EventHandler(this.Load_btn_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel2.Controls.Add(this.searchLabel);
            this.panel2.Controls.Add(this.Search_txtbx);
            this.panel2.Controls.Add(this.Load_btn);
            this.panel2.Location = new System.Drawing.Point(3, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(663, 58);
            this.panel2.TabIndex = 41;
            // 
            // Delete_btn
            // 
            this.Delete_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Delete_btn.BackColor = System.Drawing.Color.LightSlateGray;
            this.Delete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Delete_btn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete_btn.Location = new System.Drawing.Point(288, 5);
            this.Delete_btn.Name = "Delete_btn";
            this.Delete_btn.Size = new System.Drawing.Size(75, 32);
            this.Delete_btn.TabIndex = 37;
            this.Delete_btn.Text = "Delete";
            this.Delete_btn.UseVisualStyleBackColor = false;
            this.Delete_btn.Click += new System.EventHandler(this.Delete_btn_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.Delete_btn);
            this.panel1.Location = new System.Drawing.Point(0, 339);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(666, 55);
            this.panel1.TabIndex = 42;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // DeleteCloGrid
            // 
            this.DeleteCloGrid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DeleteCloGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DeleteCloGrid.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.DeleteCloGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DeleteCloGrid.Location = new System.Drawing.Point(2, 54);
            this.DeleteCloGrid.Margin = new System.Windows.Forms.Padding(0);
            this.DeleteCloGrid.Name = "DeleteCloGrid";
            this.DeleteCloGrid.Size = new System.Drawing.Size(663, 287);
            this.DeleteCloGrid.TabIndex = 43;
            this.DeleteCloGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DeleteCloGrid_CellContentClick);
            // 
            // DeleteCloPnl
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.DeleteCloGrid);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "DeleteCloPnl";
            this.Size = new System.Drawing.Size(666, 394);
            this.Load += new System.EventHandler(this.DeleteCloPnl_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DeleteCloGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox Search_txtbx;
        private System.Windows.Forms.Label searchLabel;
        private System.Windows.Forms.Button Load_btn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Delete_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView DeleteCloGrid;
    }
}
