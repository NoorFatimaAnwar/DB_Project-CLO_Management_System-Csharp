﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class rubrics : UserControl
    {
        private int rowCount = 0;
        public rubrics()
        {
            InitializeComponent();
            RowCount();
            LoadFromDataBase();
            fillComboxes();
        }

        private void LoadFromDataBase()
        {
            // filling the data in the grid
            this.RubricGridView.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT Details,CloId FROM Rubric R JOIN Clo C on C.Id = R.CloId ";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            this.RubricGridView.DataSource = dt;
            //updateRubericGV.AllowUserToAddRows= false;

            // filling the combobox


        }
        public void fillComboxes()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT CONCAT(Id,'-',Name) FROM Clo";
            SqlCommand cmd = new SqlCommand(query, con);
            using (SqlDataReader rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                {
                    CLO_linked.Items.Add(rdr.GetString(0));
                }
            }
        }
        private void AddRubericIntoDatabase(string rubericDetails, int cloID)
        {
            var con = Configuration.getInstance().getConnection();
            string query = "INSERT INTO Rubric (Id,Details,CloId) VALUES (@id,@details, @cloId)";
            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@id", this.rowCount);
            // null check on to the details parameter
            if (rubericDetails.Length > 0) cmd.Parameters.AddWithValue("@details", rubericDetails);
            else cmd.Parameters.AddWithValue("@details", DBNull.Value);

            cmd.Parameters.AddWithValue("@cloId", cloID);

            cmd.ExecuteNonQuery();



            details_txt.Text = string.Empty;
            CLO_linked.Text = string.Empty;
        }

        private void RowCount()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT COUNT(*) FROM Rubric";
            SqlCommand cmd = new SqlCommand(query, con);

            this.rowCount = (int)cmd.ExecuteScalar() + 2;
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] arr = CLO_linked.Text.Split('-');
            RowCount();
            AddRubericIntoDatabase(details_txt.Text, int.Parse(arr[0].ToString()));
            LoadFromDataBase();
        }

        private void rubrics_Load(object sender, EventArgs e)
        {

        }
    }
}
