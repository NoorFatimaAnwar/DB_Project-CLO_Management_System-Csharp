﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class ViewAss : UserControl
    {
        public ViewAss()
        {
            InitializeComponent();
            LoadAssFromDataBase();
        }

        private void allradio_btn_CheckedChanged(object sender, EventArgs e)
        {
            LoadAssFromDataBase();
        }
        private void LoadAssFromDataBase()
        {
            this.viewPnlGrid.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT Title,DateCreated,TotalMarks,TotalWeightage FROM Assessment";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            this.viewPnlGrid.DataSource = dt;
            this.viewPnlGrid.AllowUserToAddRows = false;

        }

        private void viewPnlGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            this.viewPnlGrid.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT Title,DateCreated,TotalMarks,TotalWeightage FROM Assessment  WHERE Title NOT LIKE '%deleted%'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            this.viewPnlGrid.DataSource = dt;
            this.viewPnlGrid.AllowUserToAddRows = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            this.viewPnlGrid.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT Title,DateCreated,TotalMarks,TotalWeightage FROM Assessment  WHERE Title LIKE '%deleted%'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            this.viewPnlGrid.DataSource = dt;
            this.viewPnlGrid.AllowUserToAddRows = false;
        }
    }
}
