﻿using midPro1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;


namespace midPro1
{
    public partial class student : UserControl
    {
        public student()
        {
            InitializeComponent();
        }
        public void showStudents()
        { 
        var con = Configuration.getInstance().getConnection();
        SqlCommand cmd = new SqlCommand("Select FirstName,LastName,Contact,Email,RegistrationNumber,Status from Student", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        student_GridView.DataSource = dt;
         }
   

        private void button1_Click(object sender, EventArgs e)
        {
            AddStudentIntoDatabase();
        }

        private void AddStudentIntoDatabase()
        {
            try
            {
               

                //getting params to pass into SQL query
                string firstName = Firstname_txtBox.Text;
                if (firstName.Length == 0) throw new Exception("First Name is null.");

                string lastName = Lastname_txtBox.Text;
                if (lastName.Length == 0) lastName = "";  // to insert null values into database

                string email = mail_txtBox.Text;
                if (email.Length == 0) throw new Exception("Email is null.");
                else if (email.EndsWith("@gmail.com") == false) throw new Exception("Incorrect Email.");

                string regNo = rg_txtBox.Text;
                //if (! RegistrationValidation(regNo)) throw new Exception("Duplicate Registration Number.");
                //else if (regNo.Length < 10) throw new Exception("incorrect Registration Number.");
                string contact = contact_txtBox.Text;
                if (contact.Length == 0) contact = "";    // to insert null values into database
                else if (!isValidContact(contact) || contact.Length != 11) throw new Exception("Incorrect Contact");

                //everything is fine till now, executing the Insert Statement

                 var con = Configuration.getInstance().getConnection();
                 string query = "INSERT INTO Student (FirstName,LastName,Contact,Email,RegistrationNumber,Status) VALUES (@fn,@ln,@cont,@email,@reg,@stt)";
                SqlCommand cmd = new SqlCommand(query, con);
                //cmd.Parameters.AddWithValue("@id",this.databaseStudentCount);
                cmd.Parameters.AddWithValue("@fn", firstName);

                if (lastName.Length > 0)
                    cmd.Parameters.AddWithValue("@ln", lastName);
                else
                    cmd.Parameters.AddWithValue("@ln", DBNull.Value);

                cmd.Parameters.AddWithValue("@email", email);
                if (contact.Length > 0)
                    cmd.Parameters.AddWithValue("@cont", contact);
                else
                    cmd.Parameters.AddWithValue("@cont", DBNull.Value);
                cmd.Parameters.AddWithValue("@reg", regNo);
                cmd.Parameters.AddWithValue("@stt", 5);
                cmd.ExecuteNonQuery();
            }
            catch (Exception )
            {
                MessageBox.Show("insertion failed");
            }
        }

        private bool isValidContact(string contact) // check if contact number is valid
        {
            foreach (char i in contact)
            {
                if ((int)i < 48 || (int)i > 57)
                {
                    MessageBox.Show(i.ToString());
                    return false;
                }
            }
            return true;
        }
       

        private void view_btn_Click(object sender, EventArgs e)
        {
            showStudents();
                           
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            int selectedIndex = student_GridView.SelectedCells[0].RowIndex;
            string selectedRegistrationNumber = student_GridView.Rows[selectedIndex].Cells[0].Value.ToString();
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Delete from Student  WHERE RegistrationNumber = @RegistrationNumber ", con);
            cmd.Parameters.AddWithValue("@RegistrationNumber", selectedRegistrationNumber);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
            showStudents();
        }
        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void student_Load(object sender, EventArgs e)
        {

        }
    }
}
