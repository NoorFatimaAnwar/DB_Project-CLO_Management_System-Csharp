﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class EditAssPnl : UserControl
    {
        public EditAssPnl()
        {
            InitializeComponent();
            LoadAssFromDataBase();
            setInitValues();
        }
        private void LoadAssFromDataBase()
        {
            this.EditAssGrid.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Assessment WHERE Title NOT LIKE '%deleted%'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            this.EditAssGrid.DataSource = dt;
            this.EditAssGrid.AllowUserToAddRows = false;

        }

        private void setInitValues()
        {

            this.label5.Text = DateTime.Today.Date.ToString("yyyy-MM-dd");

        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedIndex = EditAssGrid.SelectedCells[0].RowIndex;
                string selectedId = EditAssGrid.Rows[selectedIndex].Cells[0].Value.ToString();
                string details = Title_txt.Text;
                string marks = Weightage_txt.Text;


                var con = Configuration.getInstance().getConnection();
                string query = "UPDATE Assessment SET Title = @title, DateCreated = GetDate(),TotalWeightage=@weightage WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@Id", selectedId);
                cmd.Parameters.AddWithValue("@title", details);
                cmd.Parameters.AddWithValue("@weightage", marks);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully");
                LoadAssFromDataBase();
                Title_txt.Text = string.Empty;
                Weightage_txt.Value = 0;
            }
            catch (Exception)
            {
                MessageBox.Show("Updating failed");
            }
        }

        private void Delete_btn_Click(object sender, EventArgs e)
        {
            int selectedIndex = EditAssGrid.SelectedCells[0].RowIndex;
            string selectedID = EditAssGrid.Rows[selectedIndex].Cells[0].Value.ToString();
            var con = Configuration.getInstance().getConnection();
            //string query = "  Delete AssessmentComponent WHERE assessmentId = @Id; Delete Assessment WHERE Id = @Id";
            string query = "UPDATE Assessment SET Title = CONCAT('[Deleted] ', Title) WHERE Id = @Id";
            
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Id", selectedID);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Deleted Successfully");
            LoadAssFromDataBase();
        }
    }
}
