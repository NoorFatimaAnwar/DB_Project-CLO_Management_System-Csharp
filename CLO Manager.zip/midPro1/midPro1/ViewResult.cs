﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class ViewResult : UserControl
    {
        public ViewResult()
        {
            InitializeComponent();
            LoadResultFromDatabase();
        }

        private void allradio_btn_CheckedChanged(object sender, EventArgs e)
        {
            LoadResultFromDatabase();

        }
        private void LoadResultFromDatabase()
        {
            try
            {
                this.viewPnlGrid.AllowUserToAddRows = true;
                var con = Configuration.getInstance().getConnection();
                string query = "SELECT * FROM StudentResult WHERE AssessmentComponentId In ( SELECT AC.Id FROM AssessmentComponent AC JOIN Assessment A ON A.Id = AC.AssessmentId   WHERE A.Title NOT LIKE '%deleted%')  ";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                this.viewPnlGrid.DataSource = dt;
                this.viewPnlGrid.AllowUserToAddRows = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
