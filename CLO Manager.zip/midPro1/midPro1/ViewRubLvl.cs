﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class ViewRubLvl : UserControl
    {
        public ViewRubLvl()
        {
            InitializeComponent();
        }

        private void allradio_btn_CheckedChanged(object sender, EventArgs e)
        {
            LoadRubricLevelsFromDataBase();
        }
        private void LoadRubricLevelsFromDataBase()
        {

            var con = Configuration.getInstance().getConnection();
            string query = "SELECT  R.Id AS RubericID, RL.Details,RL.MeasurementLevel AS Marks, R.CloID AS MappedCLO FROM RubricLevel RL JOIN Rubric R ON R.Id = RL.RubricId";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            this.viewPnlGrid.DataSource = dt;
            this.viewPnlGrid.AllowUserToAddRows = false;
        }
    }
}
