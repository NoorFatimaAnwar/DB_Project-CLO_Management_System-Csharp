﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class AssessmentPnl : UserControl
    {
        public AssessmentPnl()
        {
            InitializeComponent();
            LoadAssFromDataBase();
            setInitValues();
        }
        private void LoadAssFromDataBase()
        {
            this.AddAssGrid.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT Title,DateCreated,TotalMarks,TotalWeightage FROM Assessment  WHERE Title NOT LIKE '%deleted%'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            this.AddAssGrid.DataSource = dt;
            this.AddAssGrid.AllowUserToAddRows = false;

        }

        private void setInitValues()
        {
        
            this.label5.Text = DateTime.Today.Date.ToString("yyyy-MM-dd");
          
        }
        private void AddAssIntoDataBase(string title,int marks, int weightage)
        {
            var con = Configuration.getInstance().getConnection();
            string query = "INSERT INTO Assessment (Title,DateCreated,TotalMarks,TotalWeightage) VALUES (@title,GETDATE() ,@marks,@weightage)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@marks", marks);
            cmd.Parameters.AddWithValue("@weightage", weightage);

            cmd.ExecuteNonQuery();
        }

        private void Delete_btn_Click(object sender, EventArgs e)
        {
            try
            {
                if (Title_txt.Text == null || Title_txt.Text == "") throw new Exception("Can not add title-less assessment. Try Again.");
                if (Convert.ToInt32(Marks_txt.Value) < 1) throw new Exception("Can not add without marks assessment. Try Again.");
                if (Convert.ToInt32(Weightage_txt.Value) < 1) throw new Exception("Can not add without weightage assessment. Try Again.");
                AddAssIntoDataBase(Title_txt.Text,  Convert.ToInt32(Marks_txt.Value), Convert.ToInt32(Weightage_txt.Value));
                LoadAssFromDataBase();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void AssessmentPnl_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
   
        }
    }
}
