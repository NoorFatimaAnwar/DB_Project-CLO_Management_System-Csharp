﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class UpdateRubricPnl : UserControl
    {
        public UpdateRubricPnl()
        {
            InitializeComponent();
            LoadFromDataBase();
        }
        private void LoadFromDataBase()
        {
            // filling the data in the grid
            this.UpdRubricGridView.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT R.Id,R.Details,CloId FROM Rubric R JOIN Clo C on C.Id = R.CloId ";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            this.UpdRubricGridView.DataSource = dt;
            //updateRubericGV.AllowUserToAddRows= false;

            // filling the combobox

         
           
        }
        private void UpdateRubricPnl_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedIndex = UpdRubricGridView.SelectedCells[0].RowIndex;
                string selectedId = UpdRubricGridView.Rows[selectedIndex].Cells[0].Value.ToString();
                string details = details_txt.Text;

                var con = Configuration.getInstance().getConnection();
                string query = "Update Rubric set  Details=@details  WHERE Id = @Id ";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Id", selectedId);

                //cmd.Parameters.AddWithValue("@id",this.databaseStudentCount);
                cmd.Parameters.AddWithValue("@details", details);
                       
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully");
                LoadFromDataBase();
                details_txt.Text = string.Empty;
             
            }
            catch (Exception)
            {
                MessageBox.Show("Updating failed");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedIndex = UpdRubricGridView.SelectedCells[0].RowIndex;
                string selectedId = UpdRubricGridView.Rows[selectedIndex].Cells[0].Value.ToString();
                string details = details_txt.Text;

                var con = Configuration.getInstance().getConnection();
                string query = "DELETE FROM StudentResult WHERE RubricMeasurementId IN (SELECT Id FROM RubricLevel WHERE RubricId = @id);DELETE FROM AssessmentComponent WHERE RubricId = @id; DELETE FROM RubricLevel WHERE RubricId = @id ; Delete Rubric WHERE Id = @Id ";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Id", selectedId);

                //cmd.Parameters.AddWithValue("@id",this.databaseStudentCount);
                cmd.Parameters.AddWithValue("@details", details);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully");
                LoadFromDataBase();
                details_txt.Text = string.Empty;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
