﻿namespace midPro1
{
    partial class StdAttendence
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AttdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.Chose_btn = new System.Windows.Forms.Button();
            this.Submit_btn = new System.Windows.Forms.Button();
            this.AttPnlGrid = new System.Windows.Forms.DataGridView();
            this.att_status = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.AttPnlGrid)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // AttdateTimePicker
            // 
            this.AttdateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AttdateTimePicker.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AttdateTimePicker.Location = new System.Drawing.Point(250, 19);
            this.AttdateTimePicker.Name = "AttdateTimePicker";
            this.AttdateTimePicker.Size = new System.Drawing.Size(200, 21);
            this.AttdateTimePicker.TabIndex = 2;
            // 
            // Chose_btn
            // 
            this.Chose_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Chose_btn.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chose_btn.Location = new System.Drawing.Point(146, 19);
            this.Chose_btn.Name = "Chose_btn";
            this.Chose_btn.Size = new System.Drawing.Size(98, 23);
            this.Chose_btn.TabIndex = 3;
            this.Chose_btn.Text = "Choose Date";
            this.Chose_btn.UseVisualStyleBackColor = true;
            this.Chose_btn.Click += new System.EventHandler(this.Chose_btn_Click);
            // 
            // Submit_btn
            // 
            this.Submit_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Submit_btn.BackColor = System.Drawing.Color.LightSlateGray;
            this.Submit_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Submit_btn.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submit_btn.Location = new System.Drawing.Point(563, 19);
            this.Submit_btn.Name = "Submit_btn";
            this.Submit_btn.Size = new System.Drawing.Size(75, 23);
            this.Submit_btn.TabIndex = 4;
            this.Submit_btn.Text = "Submit";
            this.Submit_btn.UseVisualStyleBackColor = false;
            this.Submit_btn.Click += new System.EventHandler(this.Submit_btn_Click);
            // 
            // AttPnlGrid
            // 
            this.AttPnlGrid.AllowUserToAddRows = false;
            this.AttPnlGrid.AllowUserToDeleteRows = false;
            this.AttPnlGrid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AttPnlGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AttPnlGrid.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.AttPnlGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AttPnlGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.att_status});
            this.AttPnlGrid.Location = new System.Drawing.Point(0, 58);
            this.AttPnlGrid.Name = "AttPnlGrid";
            this.AttPnlGrid.Size = new System.Drawing.Size(663, 308);
            this.AttPnlGrid.TabIndex = 5;
            // 
            // att_status
            // 
            this.att_status.HeaderText = "Status";
            this.att_status.Items.AddRange(new object[] {
            "PRESENT",
            "ABSENT",
            "LEAVE",
            "LATE"});
            this.att_status.Name = "att_status";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel2.Controls.Add(this.AttdateTimePicker);
            this.panel2.Controls.Add(this.Chose_btn);
            this.panel2.Controls.Add(this.Submit_btn);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(663, 61);
            this.panel2.TabIndex = 42;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Location = new System.Drawing.Point(0, 357);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(666, 37);
            this.panel1.TabIndex = 43;
            // 
            // StdAttendence
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.AttPnlGrid);
            this.Name = "StdAttendence";
            this.Size = new System.Drawing.Size(666, 394);
            ((System.ComponentModel.ISupportInitialize)(this.AttPnlGrid)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DateTimePicker AttdateTimePicker;
        private System.Windows.Forms.Button Chose_btn;
        private System.Windows.Forms.Button Submit_btn;
        private System.Windows.Forms.DataGridView AttPnlGrid;
        private System.Windows.Forms.DataGridViewComboBoxColumn att_status;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
    }
}
