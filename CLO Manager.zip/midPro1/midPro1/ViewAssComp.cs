﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class ViewAssComp : UserControl
    {
        public ViewAssComp()
        {
            InitializeComponent();
            LoadComponentsFromDatabase();
        }

        private void allradio_btn_CheckedChanged(object sender, EventArgs e)
        {
            LoadComponentsFromDatabase();
        }
        private void LoadComponentsFromDatabase()
        {
            try
            {
                this.viewPnlGrid.AllowUserToAddRows = true;
                var con = Configuration.getInstance().getConnection();
                string query = "SELECT AC.Name,AC.TotalMarks, A.Title AssessmentName, R.Details FROM AssessmentComponent AC JOIN Assessment A ON A.Id = AC.AssessmentId JOIN Rubric R ON R.Id = AC.RubricID  WHERE A.Title NOT LIKE '%deleted%'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                this.viewPnlGrid.DataSource = dt;
                this.viewPnlGrid.AllowUserToAddRows = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
