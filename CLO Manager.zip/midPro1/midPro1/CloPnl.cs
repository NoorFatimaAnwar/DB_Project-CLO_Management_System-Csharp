﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class CloPnl : UserControl
    {
        public CloPnl()
        {
            InitializeComponent();
            TodaysDate();
            ShowAllClos();

        }

        private void TodaysDate()
        {
            this.label3.Text = (getingRows() + 1).ToString();
            this.Date_lbl.Text = DateTime.Today.Date.ToString("yyyy-MM-dd");
            this.name_txt.Text = "";
            this.button3.Enabled = false;
        }


        private void ShowAllClos()
        {
            this.CloGridView.AllowUserToAddRows = true;
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Clo";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            this.CloGridView.DataSource = dt;
            this.CloGridView.AllowUserToAddRows = false;

            cmd.ExecuteNonQuery();
        }
        private int getingRows()
        {
            SqlCommand cmd;
            try
            {
                var con = Configuration.getInstance().getConnection();
                string query = "SELECT Id FROM Clo ORDER BY Id DESC";
                cmd = new SqlCommand(query, con);

                if (cmd.ExecuteScalar() == null) return 0;

                return (int)cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        private void AddCloInDatabase()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "INSERT INTO Clo (Name,DateCreated,DateUpdated) VALUES (@name,GETDATE(),GETDATE())";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@name", name_txt.Text);

            cmd.ExecuteNonQuery();
        }

        private void UpdateCloInDatabase(string CloName, int CloID)
        {
            try
            {
                if (CloName.Length > 18) throw new Exception("Data Length is too long. Reduce CLO name characters.");

                var con = Configuration.getInstance().getConnection();
                string query = "UPDATE Clo SET Name=@name,DateUpdated= GETDATE() WHERE Id=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", CloName);
                cmd.Parameters.AddWithValue("@id", CloID);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void InvertButtonStates(bool state)
        {
            if (state)
            {
                button1.Enabled = false;
                button3.Enabled = true;
            }
            else if (!state)
            {
                button1.Enabled = true;
                button3.Enabled = false;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            AddCloInDatabase();
            ShowAllClos();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UpdateCloInDatabase(name_txt.Text.ToString(), int.Parse(label3.Text));
            TodaysDate();
            ShowAllClos();
            InvertButtonStates(state: false);
        }

        private void CloGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == CloGridView.Columns["Update"].Index)
            {
                InvertButtonStates(state: true);
                string cloName = CloGridView[CloGridView.Columns["Name"].Index, e.RowIndex].Value.ToString();
                this.name_txt.Text = cloName;
                int cloId = int.Parse(CloGridView[CloGridView.Columns["Id"].Index, e.RowIndex].Value.ToString());
                this.label3.Text = cloId.ToString();
            }
        }

        private void UpdateCloGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Date_lbl_Click(object sender, EventArgs e)
        {

        }
    }
}
