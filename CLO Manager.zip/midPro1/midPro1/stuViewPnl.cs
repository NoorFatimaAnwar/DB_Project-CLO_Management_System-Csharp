﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class stuViewPnl : UserControl
    {
        public stuViewPnl()
        {
            InitializeComponent();
        }

        private void allradio_btn_CheckedChanged(object sender, EventArgs e)
        {

            showALLStudents();
            
        }
        

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            ShowActiveStudents();
        }
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            ShowInActiveStudents();
        }
        public void showALLStudents()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT S.RegistrationNumber AS Registration, CONCAT(S.FirstName,' ',S.LastName) AS Name,S.Contact, Lu.Name AS Status FROM Student S JOIN Lookup Lu ON Lu.LookupID = S.Status GROUP BY S.RegistrationNumber,S.FirstName,S.LastName,S.Contact,Lu.Name";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            viewPnlGrid.DataSource = dt;
        }

        private void ShowInActiveStudents()
        {
           
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT S.RegistrationNumber AS Registration, CONCAT(S.FirstName,' ',S.LastName) AS Name,S.Contact, Lu.Name AS Status FROM Student S JOIN Lookup Lu ON Lu.LookupID = S.Status AND Lu.Name = 'InActive' GROUP BY S.RegistrationNumber,S.FirstName,S.LastName,S.Contact ,Lu.Name";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            viewPnlGrid.DataSource = dt;

        }

        private void ShowActiveStudents()
        {            
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT S.RegistrationNumber AS Registration, CONCAT(S.FirstName,' ',S.LastName) AS Name,S.Contact, Lu.Name AS Status FROM Student S JOIN Lookup Lu ON Lu.LookupID = S.Status AND Lu.Name = 'Active' GROUP BY S.RegistrationNumber,S.FirstName,S.LastName,S.Contact ,Lu.Name";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            viewPnlGrid.DataSource = dt;
        }

        private void viewPnlGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
