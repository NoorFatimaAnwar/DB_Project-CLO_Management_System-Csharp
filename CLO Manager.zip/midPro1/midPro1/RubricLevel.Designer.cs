﻿namespace midPro1
{
    partial class RubricLevel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Rubriclvl_GV = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Details_txt = new System.Windows.Forms.RichTextBox();
            this.Marks = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.rubric_Combo = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.Rubriclvl_GV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Marks)).BeginInit();
            this.SuspendLayout();
            // 
            // Rubriclvl_GV
            // 
            this.Rubriclvl_GV.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Rubriclvl_GV.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.Rubriclvl_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Rubriclvl_GV.Location = new System.Drawing.Point(256, 21);
            this.Rubriclvl_GV.Name = "Rubriclvl_GV";
            this.Rubriclvl_GV.Size = new System.Drawing.Size(398, 331);
            this.Rubriclvl_GV.TabIndex = 15;
            this.Rubriclvl_GV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Rubriclvl_GV_CellContentClick);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.LightSlateGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(155, 322);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 30);
            this.button1.TabIndex = 12;
            this.button1.Text = "Insert";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 19);
            this.label2.TabIndex = 9;
            this.label2.Text = "Details";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 220);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 38);
            this.label3.TabIndex = 16;
            this.label3.Text = "Measurement \r\nLevel";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Details_txt
            // 
            this.Details_txt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Details_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Details_txt.Location = new System.Drawing.Point(27, 124);
            this.Details_txt.Name = "Details_txt";
            this.Details_txt.Size = new System.Drawing.Size(203, 57);
            this.Details_txt.TabIndex = 18;
            this.Details_txt.Text = "";
            this.Details_txt.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Marks
            // 
            this.Marks.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Marks.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Marks.Location = new System.Drawing.Point(27, 259);
            this.Marks.Name = "Marks";
            this.Marks.Size = new System.Drawing.Size(203, 26);
            this.Marks.TabIndex = 19;
            this.Marks.ValueChanged += new System.EventHandler(this.Marks_ValueChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 19);
            this.label1.TabIndex = 20;
            this.label1.Text = "Rubric ID";
            // 
            // rubric_Combo
            // 
            this.rubric_Combo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rubric_Combo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rubric_Combo.FormattingEnabled = true;
            this.rubric_Combo.Location = new System.Drawing.Point(27, 42);
            this.rubric_Combo.Name = "rubric_Combo";
            this.rubric_Combo.Size = new System.Drawing.Size(203, 27);
            this.rubric_Combo.TabIndex = 21;
            // 
            // RubricLevel
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.rubric_Combo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Marks);
            this.Controls.Add(this.Details_txt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Rubriclvl_GV);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Name = "RubricLevel";
            this.Size = new System.Drawing.Size(654, 376);
            ((System.ComponentModel.ISupportInitialize)(this.Rubriclvl_GV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Marks)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Rubriclvl_GV;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox Details_txt;
        private System.Windows.Forms.NumericUpDown Marks;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox rubric_Combo;
    }
}
