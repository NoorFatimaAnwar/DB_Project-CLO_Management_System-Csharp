﻿namespace midPro1
{
    partial class EditAssComp
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.Marks_txt = new System.Windows.Forms.NumericUpDown();
            this.Update_btn = new System.Windows.Forms.Button();
            this.EditAssCompGrid = new System.Windows.Forms.DataGridView();
            this.Title_txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Del_btn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.Ass_combo = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.Marks_txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EditAssCompGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(142, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 15);
            this.label5.TabIndex = 56;
            this.label5.Text = "DateCreated";
            // 
            // Marks_txt
            // 
            this.Marks_txt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Marks_txt.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Marks_txt.Location = new System.Drawing.Point(104, 120);
            this.Marks_txt.Name = "Marks_txt";
            this.Marks_txt.Size = new System.Drawing.Size(172, 22);
            this.Marks_txt.TabIndex = 55;
            // 
            // Update_btn
            // 
            this.Update_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Update_btn.BackColor = System.Drawing.Color.LightSlateGray;
            this.Update_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Update_btn.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update_btn.Location = new System.Drawing.Point(339, 333);
            this.Update_btn.Name = "Update_btn";
            this.Update_btn.Size = new System.Drawing.Size(75, 27);
            this.Update_btn.TabIndex = 54;
            this.Update_btn.Text = "Update";
            this.Update_btn.UseVisualStyleBackColor = false;
            this.Update_btn.Click += new System.EventHandler(this.Update_btn_Click);
            // 
            // EditAssCompGrid
            // 
            this.EditAssCompGrid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditAssCompGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.EditAssCompGrid.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.EditAssCompGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EditAssCompGrid.Location = new System.Drawing.Point(300, 31);
            this.EditAssCompGrid.Name = "EditAssCompGrid";
            this.EditAssCompGrid.Size = new System.Drawing.Size(337, 271);
            this.EditAssCompGrid.TabIndex = 53;
            // 
            // Title_txt
            // 
            this.Title_txt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Title_txt.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title_txt.Location = new System.Drawing.Point(104, 75);
            this.Title_txt.Name = "Title_txt";
            this.Title_txt.Size = new System.Drawing.Size(172, 22);
            this.Title_txt.TabIndex = 52;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(18, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 15);
            this.label3.TabIndex = 50;
            this.label3.Text = "TotalMarks";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 15);
            this.label2.TabIndex = 49;
            this.label2.Text = "DateUpdated";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 48;
            this.label1.Text = "Name";
            // 
            // Del_btn
            // 
            this.Del_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Del_btn.BackColor = System.Drawing.Color.LightSlateGray;
            this.Del_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Del_btn.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Del_btn.Location = new System.Drawing.Point(515, 333);
            this.Del_btn.Name = "Del_btn";
            this.Del_btn.Size = new System.Drawing.Size(75, 27);
            this.Del_btn.TabIndex = 60;
            this.Del_btn.Text = "Delete";
            this.Del_btn.UseVisualStyleBackColor = false;
            this.Del_btn.Click += new System.EventHandler(this.Del_btn_Click);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(18, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 15);
            this.label6.TabIndex = 62;
            this.label6.Text = "AssessmentId";
            // 
            // Ass_combo
            // 
            this.Ass_combo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Ass_combo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ass_combo.FormattingEnabled = true;
            this.Ass_combo.Location = new System.Drawing.Point(104, 156);
            this.Ass_combo.Name = "Ass_combo";
            this.Ass_combo.Size = new System.Drawing.Size(172, 23);
            this.Ass_combo.TabIndex = 61;
            // 
            // EditAssComp
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Ass_combo);
            this.Controls.Add(this.Del_btn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Marks_txt);
            this.Controls.Add(this.Update_btn);
            this.Controls.Add(this.EditAssCompGrid);
            this.Controls.Add(this.Title_txt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "EditAssComp";
            this.Size = new System.Drawing.Size(654, 376);
            ((System.ComponentModel.ISupportInitialize)(this.Marks_txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EditAssCompGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown Marks_txt;
        private System.Windows.Forms.Button Update_btn;
        private System.Windows.Forms.DataGridView EditAssCompGrid;
        private System.Windows.Forms.TextBox Title_txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Del_btn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Ass_combo;
    }
}
