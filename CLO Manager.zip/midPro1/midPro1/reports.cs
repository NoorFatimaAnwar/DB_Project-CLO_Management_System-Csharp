﻿using System;
using System.Data.SqlClient;
using System.Drawing.Drawing2D;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Font = iTextSharp.text.Font;
using System.Drawing.Imaging;
using System.Collections.Generic;
using System.Data;

namespace midPro1
{
    public partial class reports : UserControl
    {
        Font boldFont = FontFactory.GetFont(FontFactory.TIMES_BOLD, 16);
        Font textFont = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 12);
        public reports()
        {
            InitializeComponent();
            
        }

        private Document TitlePage(ref Document document)
        {
            // Add content to the document
            Paragraph title = new Paragraph("CLO Mapper and Rubric Analyzer", boldFont);
            title.Font.Size = 28;
            title.Alignment = Element.ALIGN_CENTER;
            document.Add(title);

            // Add image
            var imageURL = "uet-removebg-preview.png";
            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();

            using (Stream stream = assembly.GetManifestResourceStream(imageURL))
            {
                if (stream != null)
                {
                    iTextSharp.text.Image image = iTextSharp.text.Image.GetInstance(System.Drawing.Image.FromStream(stream), ImageFormat.Png);
                    image.ScaleAbsolute(140, 120);
                    image.Alignment = Element.ALIGN_CENTER;
                    document.Add(image);
                }
                else
                {
                    // Handle the case when the image stream is null
                    MessageBox.Show("Failed to load image from resources.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            // Add session info
            Paragraph session = new Paragraph("Session: 2022 - 2026", textFont);
            session.Alignment = Element.ALIGN_CENTER;
            document.Add(session);

            // Add submitted by
            Paragraph submittedBy = new Paragraph("Submitted By:", boldFont);
            submittedBy.Font.Size = 16;
            submittedBy.Alignment = Element.ALIGN_CENTER;
            document.Add(submittedBy);
            Paragraph submittedByDetails = new Paragraph("Noor Fatima       2022-CS-12", textFont);
            submittedByDetails.Font.Size = 14;
            submittedByDetails.Alignment = Element.ALIGN_CENTER;
            document.Add(submittedByDetails);

            // Add submitted to
            Paragraph submittedTo = new Paragraph("Submitted To:", boldFont);
            submittedTo.Font.Size = 16;
            submittedTo.Alignment = Element.ALIGN_CENTER;
            document.Add(submittedTo);
            Paragraph submittedToDetails = new Paragraph("Sir Nazeef UL Haq", textFont);
            submittedToDetails.Font.Size = 14;
            submittedToDetails.Alignment = Element.ALIGN_CENTER;
            document.Add(submittedToDetails);

            // Add department and university info
            Paragraph department = new Paragraph("Department of Computer Science", textFont);
            department.Font.Size = 18;
            department.Alignment = Element.ALIGN_CENTER;
            document.Add(department);
            Paragraph university = new Paragraph("University of Engineering And Technology, Lahore", boldFont);
            university.Font.Size = 24;
            university.Alignment = Element.ALIGN_CENTER;
            document.Add(university);
            return document;
        }



        #region CLo Wise Report
            private Document CloWiseResult(ref Document document)
            {
                try
                {
                    document.NewPage();
                    Paragraph title = new Paragraph("CLO WISE CLASS RESULT", boldFont);
                    title.SpacingBefore = 20f;
                    title.SpacingAfter = 20f;
                    title.Font.Size = 20;
                    title.Alignment = Element.ALIGN_CENTER;
                    document.Add(title);

                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("SELECT Student.FirstName+' '+Student.LastName AS [Student Name], Student.RegistrationNumber AS [Registration Number], Clo.Name AS [CLO Name], " +
                                      "SUM(AssessmentComponent.TotalMarks) AS [Total Marks], " +
                                      "SUM((CAST(RubricLevel.MeasurementLevel AS FLOAT) / NULLIF([max measurement level].maxLevel, 0)) * AssessmentComponent.TotalMarks) AS [Obtained Marks], " +
                                      "(((SUM((CAST(RubricLevel.MeasurementLevel AS FLOAT) / NULLIF([max measurement level].maxLevel, 0)) * AssessmentComponent.TotalMarks)) * 100) / NULLIF(SUM(AssessmentComponent.TotalMarks), 0)) AS [Percentage] " +
                                      "FROM Student " +
                                      "INNER JOIN StudentResult ON Student.Id = StudentResult.StudentId " +
                                      "INNER JOIN RubricLevel ON StudentResult.RubricMeasurementId = RubricLevel.Id " +
                                      "INNER JOIN AssessmentComponent ON AssessmentComponent.Id = StudentResult.AssessmentComponentId " +
                                      "INNER JOIN Assessment ON Assessment.Id = AssessmentComponent.AssessmentId " +
                                      "INNER JOIN Rubric ON Rubric.Id = RubricLevel.RubricId " +
                                      "INNER JOIN Clo ON Clo.Id = Rubric.CloId " +
                                      "INNER JOIN (SELECT RubricLevel.RubricId AS Rid, MAX(RubricLevel.MeasurementLevel) AS maxLevel FROM RubricLevel GROUP BY RubricLevel.RubricId) AS [max measurement level] " +
                                      "ON [max measurement level].Rid = Rubric.Id " +
                                      "WHERE Student.Status = 5 " +
                                      "AND Rubric.Details NOT LIKE '% -(0)' " +
                                      "AND RubricLevel.Details NOT LIKE '% -(0)' " +
                                      "AND StudentResult.EvaluationDate != '1753-01-01 00:00:00.000' " +
                                      "AND AssessmentComponent.Name NOT LIKE '% -(0)' " +
                                      "AND Assessment.Title NOT LIKE '% -(0)' " +
                                      "AND Clo.Name NOT LIKE '% -(0)' " +
                                      "GROUP BY Clo.Name, Student.FirstName, Student.LastName, Student.RegistrationNumber", con);

                    SqlDataReader reader = cmd.ExecuteReader();

                    PdfPTable table = new PdfPTable(reader.FieldCount);
                    table.WidthPercentage = 100;
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        cell.BackgroundColor = new BaseColor(128, 128, 128);
                        table.AddCell(cell);
                    }

                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            PdfPCell cell = new PdfPCell(new Phrase(reader[i].ToString()));
                            cell.HorizontalAlignment = Element.ALIGN_CENTER;
                            table.AddCell(cell);
                        }
                    }
                    reader.Close();
                    document.Add(table);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                return document;
            }


            private void GenerateCloWiseReport()
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF (.pdf)|.pdf";
            sfd.FileName = "CloWiseResult.pdf";
            bool errorMessage = false;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(sfd.FileName))
                {
                    try
                    {
                        File.Delete(sfd.FileName);


                    }
                    catch (Exception ex)
                    {
                        errorMessage = true;
                        MessageBox.Show("Unable to write data in disk" + ex.Message);
                    }
                }
                if (!errorMessage)
                {
                    // Create new PDF document
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sfd.FileName, FileMode.Create));
                    document.Open();


                    //document = TitlePage(ref document);
                    document = CloWiseResult(ref document);

                    // Close PDF document and writer
                    document.Close();
                    writer.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GenerateCloWiseReport();
        }
        #endregion CLO Wise Report


        #region Ass Component Wise Report

        private Document Ass_CompWiseResult(ref Document document)
        {
            try
            {
                document.NewPage();
                Paragraph title = new Paragraph("ASSESSMENT COMPONENT WISE CLASS RESULT", boldFont);
                title.SpacingBefore = 20f;
                title.SpacingAfter = 20f;
                title.Font.Size = 20;
                title.Alignment = Element.ALIGN_CENTER;
                document.Add(title);

                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("SELECT (SELECT CONCAT(S.FirstName,' ',S.LastName) FROM Student S  WHERE S.Id = SR.StudentID) Name,\r\nCONCAT(C.Id,'-',C.Name)'CLO',CONVERT(date,SR.EvaluationDate) 'Eval_Date',A.Title 'Assessment',AC.Name as Ass_Component,AC.TotalMarks,RL.MeasurementLevel 'TotalObtMarks',\r\n(SELECT MAX( RLP.MeasurementLevel) FROM RubricLevel RLP WHERE RLP.RubricId = R.Id) as 'MaxMarks',\r\nCAST(((CAST(RL.MeasurementLevel AS FLOAT) / CAST((SELECT MAX( RLP.MeasurementLevel ) FROM RubricLevel RLP WHERE RLP.RubricId = R.Id)AS FLOAT))) * CAST(AC.TotalMarks AS FLOAT) AS DECIMAL(16,2))\r\n'ObtainedMarks' \r\nFROM Assessment A\r\nJOIN AssessmentComponent AC ON AC.AssessmentId = A.Id\r\nJOIN StudentResult SR ON SR.AssessmentComponentId = AC.Id\r\nJOIN RubricLevel RL ON SR.RubricMeasurementId = RL.Id\r\nJOIN Rubric R ON RL.RubricId = R.Id\r\nJOIN Clo C ON R.CloId = C.Id\r\nGROUP BY  A.Title,SR.StudentID,AC.Name,AC.TotalMarks,RL.Id,RL.MeasurementLevel,SR.RubricMeasurementId,R.Id,C.Name,C.Id,SR.EvaluationDate,A.TotalWeightage\r\nORDER BY SR.StudentId ASC,C.Id ASC;", con);

                SqlDataReader reader = cmd.ExecuteReader();

                PdfPTable table = new PdfPTable(reader.FieldCount);
                table.WidthPercentage = 100;
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    cell.BackgroundColor = new BaseColor(128, 128, 128);
                    table.AddCell(cell);
                }

                while (reader.Read())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(reader[i].ToString()));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        table.AddCell(cell);
                    }
                }
                reader.Close();
                document.Add(table);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return document;
        }
        private void GenerateAssCompWiseReport()
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF (.pdf)|.pdf";
            sfd.FileName = "Ass_CompWiseResult.pdf";
            bool errorMessage = false;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(sfd.FileName))
                {
                    try
                    {
                        File.Delete(sfd.FileName);


                    }
                    catch (Exception ex)
                    {
                        errorMessage = true;
                        MessageBox.Show("Unable to write data in disk" + ex.Message);
                    }
                }
                if (!errorMessage)
                {
                    // Create new PDF document
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sfd.FileName, FileMode.Create));
                    document.Open();


                   // document = TitlePage(ref document);
                    document = Ass_CompWiseResult(ref document);

                    // Close PDF document and writer
                    document.Close();
                    writer.Close();
                }
            }
        }
        #endregion Ass Component Wise Report


        #region Assessment Wise Report

        private Document AssessmentWiseResult(ref Document document)
        {
            try
            {
                document.NewPage();
                Paragraph title = new Paragraph("Assessment WISE CLASS RESULT", boldFont);
                title.SpacingBefore = 20f;
                title.SpacingAfter = 20f;
                title.Font.Size = 20;
                title.Alignment = Element.ALIGN_CENTER;
                document.Add(title);

                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("SELECT S.FirstName+' '+S.LastName AS [Student Name], S.RegistrationNumber AS [Registration Number], Assessment.Title AS [Assessment Title], " +
                                "SUM(AssessmentComponent.TotalMarks) AS [Total Marks], " +
                                "SUM((CAST(RubricLevel.MeasurementLevel AS FLOAT) / NULLIF([MaximumMeasurementLevel].maximum, 0)) * AssessmentComponent.TotalMarks) AS [Obtained Marks], " +
                                "((SUM((CAST(RubricLevel.MeasurementLevel AS FLOAT) / NULLIF([MaximumMeasurementLevel].maximum, 0)) * AssessmentComponent.TotalMarks)) / NULLIF(SUM(AssessmentComponent.TotalMarks), 0)) * 100 AS [Percentage] " +
                                "FROM Student AS S " +
                                "INNER JOIN StudentResult ON S.Id = StudentResult.StudentId " +
                                "INNER JOIN RubricLevel ON StudentResult.RubricMeasurementId = RubricLevel.Id " +
                                "INNER JOIN AssessmentComponent ON AssessmentComponent.Id = StudentResult.AssessmentComponentId " +
                                "INNER JOIN Assessment ON Assessment.Id = AssessmentComponent.AssessmentId " +
                                "INNER JOIN Rubric ON Rubric.Id = RubricLevel.RubricId " +
                                "INNER JOIN (SELECT RubricId, MAX(MeasurementLevel) AS maximum FROM RubricLevel GROUP BY RubricId) AS [MaximumMeasurementLevel] " +
                                "ON [MaximumMeasurementLevel].RubricId = Rubric.Id " +
                                "WHERE S.Status = 5 " +
                                "AND Rubric.Details NOT LIKE '% -(0)' " +
                                "AND RubricLevel.Details NOT LIKE '% -(0)' " +
                                "AND StudentResult.EvaluationDate != '1753-01-01 00:00:00.000' " +
                                "AND AssessmentComponent.Name NOT LIKE '% -(0)' " +
                                "AND Assessment.Title NOT LIKE '% -(0)' " +
                                "GROUP BY S.FirstName, S.LastName, S.RegistrationNumber, Assessment.Title", con);

                SqlDataReader reader = cmd.ExecuteReader();

                PdfPTable table = new PdfPTable(reader.FieldCount);
                table.WidthPercentage = 100;
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    cell.BackgroundColor = new BaseColor(128, 128, 128);
                    table.AddCell(cell);
                }

                while (reader.Read())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(reader[i].ToString()));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        table.AddCell(cell);
                    }
                }
                reader.Close();
                document.Add(table);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return document;
        }


        private void GenerateAssessmentWiseReport()
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF (.pdf)|.pdf";
            sfd.FileName = "AssessmentWiseResult.pdf";
            bool errorMessage = false;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(sfd.FileName))
                {
                    try
                    {
                        File.Delete(sfd.FileName);


                    }
                    catch (Exception ex)
                    {
                        errorMessage = true;
                        MessageBox.Show("Unable to write data in disk" + ex.Message);
                    }
                }
                if (!errorMessage)
                {
                    // Create new PDF document
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sfd.FileName, FileMode.Create));
                    document.Open();


                    //document = TitlePage(ref document);
                    document = AssessmentWiseResult(ref document);

                    // Close PDF document and writer
                    document.Close();
                    writer.Close();
                }
            }
        }
        #endregion Assessment Wise Report

        #region Student Wise Att Report

        private Document StuAttWiseResult(ref Document document)
        {
            try
            {
                document.NewPage();
                Paragraph title = new Paragraph("STUDENT WISE ASSESSMENT RESULT", boldFont);
                title.SpacingBefore = 20f;
                title.SpacingAfter = 20f;
                title.Font.Size = 20;
                title.Alignment = Element.ALIGN_CENTER;
                document.Add(title);

                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand(@"SELECT (SELECT RegistrationNumber FROM Student WHERE Id=S.Id)'Registration Number',   COUNT(*) 'Total Presents', (SELECT COUNT(*) FROM ClassAttendance CAtt JOIN StudentAttendance SAtt ON CAtt.Id=SAtt.AttendanceId) 'Total Classes Entered'  ,CAST((CAST(COUNT(*)  AS DECIMAL(16,2)) / CAST( (SELECT COUNT(*) FROM ClassAttendance CAtt JOIN StudentAttendance SAtt ON CAtt.Id=SAtt.AttendanceId) AS numeric(16,2)) * 100 ) as numeric(16, 2)) AS 'Attendance Percentage'  FROM StudentAttendance SA   JOIN Student S  ON S.Id=SA.StudentId   GROUP BY S.Id ", con);
                SqlDataReader reader = cmd.ExecuteReader();

                PdfPTable table = new PdfPTable(reader.FieldCount);
                table.WidthPercentage = 100;
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    cell.BackgroundColor = new BaseColor(128, 128, 128);
                    table.AddCell(cell);
                }

                while (reader.Read())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(reader[i].ToString()));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        table.AddCell(cell);
                    }
                }
                reader.Close();
                document.Add(table);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return document;
        }

        private void GenerateStuWiseAttReport()
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF (.pdf)|.pdf";
            sfd.FileName = "Stu_WiseAttendenceResult.pdf";
            bool errorMessage = false;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(sfd.FileName))
                {
                    try
                    {
                        File.Delete(sfd.FileName);


                    }
                    catch (Exception ex)
                    {
                        errorMessage = true;
                        MessageBox.Show("Unable to write data in disk" + ex.Message);
                    }
                }
                if (!errorMessage)
                {
                    // Create new PDF document
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sfd.FileName, FileMode.Create));
                    document.Open();


                    //document = TitlePage(ref document);
                    document = StuAttWiseResult(ref document);

                    // Close PDF document and writer
                    document.Close();
                    writer.Close();
                }
            }
        }
        #endregion Student Wise Att Report

        #region Class Wise Att Report

        private Document ClassAttWiseResult(ref Document document)
        {
            try
            {
                document.NewPage();
                Paragraph title = new Paragraph("CLASS WISE ATTENDENCE RESULT", boldFont);
                title.SpacingBefore = 20f;
                title.SpacingAfter = 20f;
                title.Font.Size = 20;
                title.Alignment = Element.ALIGN_CENTER;
                document.Add(title);

                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("SELECT  CAtt.Id AS 'Class ID',     COUNT(SAtt.StudentId) AS 'Total Students Present', COUNT(*) AS 'Total Classes Entered',   CAST((CAST(COUNT(SAtt.StudentId) AS DECIMAL(16, 2)) / CAST(COUNT(*) AS DECIMAL(16, 2)) * 100) AS DECIMAL(16, 2)) AS 'Attendance Percentage' FROM   ClassAttendance CAtt JOIN  StudentAttendance SAtt ON CAtt.Id = SAtt.AttendanceId GROUP BY  CAtt.Id", con);
                SqlDataReader reader = cmd.ExecuteReader();

                PdfPTable table = new PdfPTable(reader.FieldCount);
                table.WidthPercentage = 100;
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    cell.BackgroundColor = new BaseColor(128, 128, 128);
                    table.AddCell(cell);
                }

                while (reader.Read())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(reader[i].ToString()));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        table.AddCell(cell);
                    }
                }
                reader.Close();
                document.Add(table);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return document;
        }

        private void GenerateClassWiseAttReport()
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF (.pdf)|.pdf";
            sfd.FileName = "Class_WiseAttendenceResult.pdf";
            bool errorMessage = false;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(sfd.FileName))
                {
                    try
                    {
                        File.Delete(sfd.FileName);


                    }
                    catch (Exception ex)
                    {
                        errorMessage = true;
                        MessageBox.Show("Unable to write data in disk" + ex.Message);
                    }
                }
                if (!errorMessage)
                {
                    // Create new PDF document
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sfd.FileName, FileMode.Create));
                    document.Open();


                   // document = TitlePage(ref document);
                    document = ClassAttWiseResult(ref document);

                    // Close PDF document and writer
                    document.Close();
                    writer.Close();
                }
            }
        }
        #endregion Class Wise Att Report
        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            GenerateAssessmentWiseReport();
        }

        private void Delete_btn_Click(object sender, EventArgs e)
        {
            GenerateAssCompWiseReport();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            GenerateStuWiseAttReport();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            GenerateClassWiseAttReport();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
