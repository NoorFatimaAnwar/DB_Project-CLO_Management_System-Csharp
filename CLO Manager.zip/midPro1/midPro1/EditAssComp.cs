﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class EditAssComp : UserControl
    {
        public EditAssComp()
        {
            InitializeComponent();
            LoadComponentsFromDatabase();
            TodaysDate();
            FillComboBoxes();


        }
        private void LoadComponentsFromDatabase()
        {
            try
            {
                this.EditAssCompGrid.AllowUserToAddRows = true;
                var con = Configuration.getInstance().getConnection();
                string query = "SELECT AC.Id, AC.Name,AC.TotalMarks, A.Title AssessmentName,AC.DateCreated,AC.DateUpdated, R.Details FROM AssessmentComponent AC JOIN Assessment A ON A.Id = AC.AssessmentId JOIN Rubric R ON R.Id = AC.RubricID  WHERE A.Title NOT LIKE '%deleted%'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
               
                da.Fill(dt);
                this.EditAssCompGrid.DataSource = dt;
                this.EditAssCompGrid.AllowUserToAddRows = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void TodaysDate()
        {
            
            this.label5.Text = DateTime.Today.Date.ToString("yyyy-MM-dd");
           
        }

        private void FillComboBoxes()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT CONCAT(Id,'-',Title) FROM Assessment  WHERE Title NOT LIKE '%deleted%'";
            SqlCommand cmd = new SqlCommand(query, con);
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Ass_combo.Items.Add(reader.GetString(0));
                }
            }
            this.Ass_combo.SelectedIndex = 0;
           
        }

        private int GetAssessmentComponentMarksTotal(int assId)
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT SUM(TotalMarks) FROM AssessmentComponent WHERE AssessmentId=@assId";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("assId", assId);
            if (cmd.ExecuteScalar() == null || cmd.ExecuteScalar().ToString() == "") return 0;
            return (int)cmd.ExecuteScalar();
        }

        private int GetAssessmentMarksTotal(int assId)
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT TotalMarks FROM Assessment WHERE Id=@assId";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("assId", assId);
            //MessageBox.Show(cmd.ExecuteScalar().ToString());
            return (int)cmd.ExecuteScalar();
        }

        private void UpdateComponentIntoDataBase(string name, int totalMarks,  int assessmentId)
        {
            // MessageBox.Show(assessmentId.ToString());
            int selectedIndex = EditAssCompGrid.SelectedCells[0].RowIndex;
            string selectedId = EditAssCompGrid.Rows[selectedIndex].Cells[0].Value.ToString();
            var con = Configuration.getInstance().getConnection();
            string query = "Update  AssessmentComponent set Name=@name,TotalMarks=@totalMarks,DateUpdated=GETDATE(),AssessmentId=@assessmentId Where Id=@Id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Id", selectedId);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@totalMarks", totalMarks);
            cmd.Parameters.AddWithValue("@assessmentId", assessmentId);

            cmd.ExecuteNonQuery();
        }
        private void Update_btn_Click(object sender, EventArgs e)
        {
            try
            {
              
                if (Title_txt.Text == null || Title_txt.Text == "") throw new Exception("Name-less assessment component can not be created, try again");
                int totalMarks = int.Parse(Marks_txt.Value.ToString());

                
                int assessmentId = int.Parse((Ass_combo.Text.Split('-'))[0].ToString());
                if (totalMarks + GetAssessmentComponentMarksTotal(assessmentId) > GetAssessmentMarksTotal(assessmentId))
                {
                    throw new Exception("Can not add more than assessment Marks.");
                }
                UpdateComponentIntoDataBase(Title_txt.Text, totalMarks,  assessmentId);
                LoadComponentsFromDatabase();
                Title_txt.Text = string.Empty;
                Marks_txt.Value = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Del_btn_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedIndex = EditAssCompGrid.SelectedCells[0].RowIndex;
                string selectedId = EditAssCompGrid.Rows[selectedIndex].Cells[0].Value.ToString();
                var con = Configuration.getInstance().getConnection();
                string query = "DELETE FROM StudentResult WHERE AssessmentComponentId = @id ;DELETE FROM AssessmentComponent WHERE Id = @id";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@id", selectedId);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully");
                LoadComponentsFromDatabase();

            }
            catch (Exception)
            {
                MessageBox.Show("Deletion failed");
            }
        }
    }
}
