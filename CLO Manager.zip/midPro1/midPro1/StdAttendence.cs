﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class StdAttendence : UserControl
    {
        int classID = 0;
        int clickCount = 0;
        public StdAttendence()
        {
            InitializeComponent();
            ShowAllStds();
        }

        private void Chose_btn_Click(object sender, EventArgs e)
        {
           
            this.AttdateTimePicker.Visible = true;
            this.Chose_btn.Visible = false;
            
            
        }
        public void ShowAllStds()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT RegistrationNumber AS Registration,  CONCAT (FirstName, ' ', LastName) AS Name FROM Student S WHERE S.Status = 5";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            AttPnlGrid.DataSource = dt;
        }
        private void InsertTodaysClassID()
        {
            // query to set today's class Attendance into the database table
            string query = "INSERT INTO ClassAttendance (AttendanceDate) VALUES (CAST( GETDATE() AS Date ))";
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            query = "SELECT TOP(1) Id FROM ClassAttendance ORDER BY Id DESC";
            con = Configuration.getInstance().getConnection();
            cmd = new SqlCommand(query, con);
            this.classID = (int)cmd.ExecuteScalar();
            //MessageBox.Show(classID.ToString());
        }

        private void InsertStudentAttendance()
        {
            try
            {
                string registration = "";
                int sID = 0;
                foreach (DataGridViewRow row in this.AttPnlGrid.Rows)
                {
                    registration = row.Cells[1].Value.ToString();
                    sID = GetStudentIDByRegistration(registration);

                    if (row.Cells[0].Value == null) throw new Exception("Attendance not marked against a student");

                    else if (row.Cells[0].Value.ToString() == "PRESENT")
                    {
                        InsertStudentDBValues(sID, 1);
                    }
                    else if (row.Cells[0].Value.ToString() == "ABSENT")
                    {
                        InsertStudentDBValues(sID, 2);
                    }
                    else if (row.Cells[0].Value.ToString() == "LEAVE")
                    {
                        InsertStudentDBValues(sID, 3);
                    }
                    else if (row.Cells[0].Value.ToString() == "LATE")
                    {
                        InsertStudentDBValues(sID, 4);
                    }
                }
                MessageBox.Show("All Attendances have been successfully inserted for today.");
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void InsertStudentDBValues(int sID, int status)
        {

            var con = Configuration.getInstance().getConnection();
            string query = "INSERT INTO StudentAttendance (AttendanceID,StudentID,AttendanceStatus) VALUES (@attID,@stuID,@stat)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@attID", this.classID);
            cmd.Parameters.AddWithValue("@stuID", sID);
            cmd.Parameters.AddWithValue("@stat", status);
            cmd.ExecuteNonQuery();
        }
        private int GetStudentIDByRegistration(string registration)
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT Id FROM Student WHERE RegistrationNumber = @reg";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@reg", registration);
            return (int)cmd.ExecuteScalar();
        }
        private void Submit_btn_Click(object sender, EventArgs e)
        {
            if (clickCount == 0)
            {
                clickCount++;
                InsertTodaysClassID();
            }
            InsertStudentAttendance();
        }
    }
}
