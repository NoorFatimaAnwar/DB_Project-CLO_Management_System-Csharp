﻿namespace midPro1
{
    partial class DeleteStudents
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DeleteGrid = new System.Windows.Forms.DataGridView();
            this.Delete_btn = new System.Windows.Forms.Button();
            this.Search_txtbx = new System.Windows.Forms.TextBox();
            this.searchLabel = new System.Windows.Forms.Label();
            this.Load_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.DeleteGrid)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // DeleteGrid
            // 
            this.DeleteGrid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DeleteGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DeleteGrid.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.DeleteGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DeleteGrid.Location = new System.Drawing.Point(0, 54);
            this.DeleteGrid.Margin = new System.Windows.Forms.Padding(0);
            this.DeleteGrid.Name = "DeleteGrid";
            this.DeleteGrid.Size = new System.Drawing.Size(663, 287);
            this.DeleteGrid.TabIndex = 1;
            // 
            // Delete_btn
            // 
            this.Delete_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Delete_btn.BackColor = System.Drawing.Color.LightSlateGray;
            this.Delete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Delete_btn.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete_btn.Location = new System.Drawing.Point(289, 9);
            this.Delete_btn.Name = "Delete_btn";
            this.Delete_btn.Size = new System.Drawing.Size(86, 32);
            this.Delete_btn.TabIndex = 30;
            this.Delete_btn.Text = "Delete";
            this.Delete_btn.UseVisualStyleBackColor = false;
            this.Delete_btn.Click += new System.EventHandler(this.Delete_btn_Click);
            // 
            // Search_txtbx
            // 
            this.Search_txtbx.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Search_txtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search_txtbx.Location = new System.Drawing.Point(187, 18);
            this.Search_txtbx.Name = "Search_txtbx";
            this.Search_txtbx.Size = new System.Drawing.Size(264, 22);
            this.Search_txtbx.TabIndex = 35;
            this.Search_txtbx.TextChanged += new System.EventHandler(this.Search_txtbx_TextChanged);
            // 
            // searchLabel
            // 
            this.searchLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.searchLabel.AutoSize = true;
            this.searchLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchLabel.Location = new System.Drawing.Point(85, 21);
            this.searchLabel.Name = "searchLabel";
            this.searchLabel.Size = new System.Drawing.Size(96, 15);
            this.searchLabel.TabIndex = 34;
            this.searchLabel.Text = "Search by regNo";
            this.searchLabel.Click += new System.EventHandler(this.searchLabel_Click);
            // 
            // Load_btn
            // 
            this.Load_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Load_btn.BackColor = System.Drawing.Color.LightSlateGray;
            this.Load_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Load_btn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Load_btn.Location = new System.Drawing.Point(470, 18);
            this.Load_btn.Name = "Load_btn";
            this.Load_btn.Size = new System.Drawing.Size(116, 23);
            this.Load_btn.TabIndex = 33;
            this.Load_btn.Text = "Load Database";
            this.Load_btn.UseVisualStyleBackColor = false;
            this.Load_btn.Click += new System.EventHandler(this.Load_btn_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.Delete_btn);
            this.panel1.Location = new System.Drawing.Point(0, 339);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(666, 55);
            this.panel1.TabIndex = 36;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel2.Controls.Add(this.searchLabel);
            this.panel2.Controls.Add(this.Search_txtbx);
            this.panel2.Controls.Add(this.Load_btn);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(663, 58);
            this.panel2.TabIndex = 37;
            // 
            // DeleteStudents
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.DeleteGrid);
            this.Name = "DeleteStudents";
            this.Size = new System.Drawing.Size(666, 394);
            ((System.ComponentModel.ISupportInitialize)(this.DeleteGrid)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView DeleteGrid;
        private System.Windows.Forms.Button Delete_btn;
        private System.Windows.Forms.TextBox Search_txtbx;
        private System.Windows.Forms.Label searchLabel;
        private System.Windows.Forms.Button Load_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}
