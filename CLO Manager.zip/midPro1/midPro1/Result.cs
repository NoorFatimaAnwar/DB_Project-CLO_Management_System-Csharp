﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace midPro1
{
    public partial class Result : UserControl
    {
        int clickcount = 0; 
        public Result()
        {
            InitializeComponent();
            LoadResultFromDatabase();
            FillComboBoxes();
            TodaysDate();
        }
        private void TodaysDate()
        {

            this.label5.Text = DateTime.Today.Date.ToString("yyyy-MM-dd");

        }

        private void LoadResultFromDatabase()
        {
            try
            {
                this.ResultGrid.AllowUserToAddRows = true;
                var con = Configuration.getInstance().getConnection();
                string query = "SELECT * FROM StudentResult WHERE AssessmentComponentId In ( SELECT AC.Id FROM AssessmentComponent AC JOIN Assessment A ON A.Id = AC.AssessmentId   WHERE A.Title NOT LIKE '%deleted%') ";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                this.ResultGrid.DataSource = dt;
                this.ResultGrid.AllowUserToAddRows = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FillComboBoxes()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT CONCAT(R.Id,'|',R.Details) FROM RubricLevel R";
            SqlCommand cmd = new SqlCommand(query, con);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Rub_combo.Items.Add(reader.GetString(0));
                }
            }

            query = "SELECT CONCAT(AC.Id,'|',AC.Name) FROM AssessmentComponent  AC JOIN Assessment A ON A.Id = AC.AssessmentId   WHERE A.Title NOT LIKE '%deleted%' ";
            cmd = new SqlCommand(query, con);
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Ass_combo.Items.Add(reader.GetString(0));
                }
            }

            query = "SELECT CONCAT(Id,'|',RegistrationNumber) FROM Student WHERE Status = 5";
            cmd = new SqlCommand(query, con);
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    StuCombo.Items.Add(reader.GetString(0));
                }
            }
          /*  this.Ass_combo.SelectedIndex = 0;
            this.Rub_combo.SelectedIndex = 0;
            this.StuCombo.SelectedIndex = 0;*/
        }

        private void AddResultIntoDataBase( int StuName, int rubricId, int assessmentId)
        {
            // MessageBox.Show(assessmentId.ToString());
            var con = Configuration.getInstance().getConnection();
            string query = "INSERT INTO StudentResult (StudentId,AssessmentComponentId,RubricMeasurementId,EvaluationDate ) VALUES (@stuId,@assId,@rubricId,GETDATE())";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@stuId", StuName);
            cmd.Parameters.AddWithValue("@assId", assessmentId);
            cmd.Parameters.AddWithValue("@rubricId", rubricId);
  

            cmd.ExecuteNonQuery();
        }
        private void Delete_btn_Click(object sender, EventArgs e)
        {
            try
            {
                
                int Stu_Name = int.Parse((StuCombo.Text.Split('|'))[0].ToString());

                int rubricId = int.Parse((Rub_combo.Text.Split('|'))[0].ToString());
                int assessmentId = int.Parse((Ass_combo.Text.Split('|'))[0].ToString());
                AddResultIntoDataBase(Stu_Name, rubricId, assessmentId);
                LoadResultFromDatabase();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                StuCombo.Enabled = true;
                int selectedIndex = ResultGrid.SelectedCells[0].RowIndex;
                string selectedId = ResultGrid.Rows[selectedIndex].Cells[0].Value.ToString();
                var con = Configuration.getInstance().getConnection();
                string query = "DELETE FROM StudentResult WHERE StudentId = @id";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@id", selectedId);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully");
                LoadResultFromDatabase();

            }
            catch (Exception)
            {
                MessageBox.Show("Deletion failed");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedIndex = ResultGrid.SelectedCells[0].RowIndex;
                string selectedId = ResultGrid.Rows[selectedIndex].Cells[0].Value.ToString();
                

                int rubricId = int.Parse((Rub_combo.Text.Split('|'))[0].ToString());
                int assessmentId = int.Parse((Ass_combo.Text.Split('|'))[0].ToString());


                var con = Configuration.getInstance().getConnection();
                string query = "UPDATE StudentResult SET AssessmentComponentId = @AssComp, RubricMeasurementId = @RubricID, EvaluationDate=GetDate() WHERE studentId = @Id";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@Id", selectedId);
                cmd.Parameters.AddWithValue("@AssComp", assessmentId);
                cmd.Parameters.AddWithValue("@RubricID", rubricId);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully");
                LoadResultFromDatabase();
                StuCombo.Enabled = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void ResultGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
                     
        }
    }
}
