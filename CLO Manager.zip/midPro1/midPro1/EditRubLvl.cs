﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class EditRubLvl : UserControl
    {
        public EditRubLvl()
        {
            InitializeComponent();
            LoadRubricLevelsFromDataBase();
        }

        private void LoadRubricLevelsFromDataBase()
        {

            var con = Configuration.getInstance().getConnection();
            string query = "SELECT RL.Id, R.Id AS RubericID, RL.Details,RL.MeasurementLevel AS Marks, R.CloID AS MappedCLO FROM RubricLevel RL JOIN Rubric R ON R.Id = RL.RubricId";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            this.Rubriclvl_GV.DataSource = dt;
            this.Rubriclvl_GV.AllowUserToAddRows = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedIndex = Rubriclvl_GV.SelectedCells[0].RowIndex;
                string selectedId = Rubriclvl_GV.Rows[selectedIndex].Cells[0].Value.ToString();
                string details = Details_txt.Text;
                string marks = Marks.Text;


                var con = Configuration.getInstance().getConnection();
                string query = "UPDATE RubricLevel SET Details = @det,MeasurementLevel=@measurelevel WHERE Id = @rid";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@rid", selectedId);
                cmd.Parameters.AddWithValue("@det", details);
                cmd.Parameters.AddWithValue("@measurelevel", marks);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully");
                LoadRubricLevelsFromDataBase();
                Details_txt.Text = string.Empty;
                Marks.Value = 0;
            }
            catch (Exception)
            {
                MessageBox.Show("Updating failed");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedIndex = Rubriclvl_GV.SelectedCells[0].RowIndex;
                string selectedId = Rubriclvl_GV.Rows[selectedIndex].Cells[0].Value.ToString();
                var con = Configuration.getInstance().getConnection();
                string query = "DELETE FROM StudentResult WHERE RubricMeasurementId = @id ;DELETE FROM RubricLevel WHERE Id = @id";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@id", selectedId);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully");
                LoadRubricLevelsFromDataBase();
                
            }
            catch (Exception)
            {
                MessageBox.Show("Deletion failed");
            }

        }
    }
}
