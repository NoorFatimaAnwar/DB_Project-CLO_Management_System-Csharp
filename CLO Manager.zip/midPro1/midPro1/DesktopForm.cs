﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using midPro1;


namespace midPro1
{
    public partial class DesktopForm : Form
    {
        public DesktopForm()
        {
            InitializeComponent();
        }

        private void addPanels(UserControl panel)
        {
            panel.Dock = DockStyle.Fill;
            panel2.Controls.Clear();
            panel2.Controls.Add(panel);
            panel.BringToFront();
            
        }
        private void button1_Click(object sender, EventArgs e)
        {

            AddStudent manageStuAddPnl = new AddStudent();
            addPanels(manageStuAddPnl);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            CloPnl manageClos = new CloPnl();
            addPanels(manageClos);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            rubrics manageRubrics = new rubrics();
            addPanels(manageRubrics);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            RubricLevel manageRubricLevel = new RubricLevel();
            addPanels(manageRubricLevel);

        }

        private void student_combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.label1.Text = "Student Form";

            if (student_combo.Text == "Add")
            {
                AddStudent manageStuAddPnl = new AddStudent();
                addPanels(manageStuAddPnl);
            }
            if (student_combo.Text == "Delete")
            {

                DeleteStudents manageStuDelPnl = new DeleteStudents();
                addPanels(manageStuDelPnl);


            }
            if (student_combo.Text == "Update")
            {

                stdUpdPnl manageStuUpdPnl = new stdUpdPnl();
                addPanels(manageStuUpdPnl);


            }
        
            if (student_combo.Text == "View")
            {
                stuViewPnl manageStuViewPnl = new stuViewPnl();
                addPanels(manageStuViewPnl);

            }
        

        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.label1.Text = "CLO Form";
            if (Clo_combo.Text == "Edit")
            {
                CloPnl manageAddCloPnl = new CloPnl();
                addPanels(manageAddCloPnl);

            }
            if (Clo_combo.Text == "Delete")
            {
                DeleteCloPnl manageDelCloPnl = new DeleteCloPnl();
                addPanels(manageDelCloPnl);

            }
            if (Clo_combo.Text == "View")
            {
                ViewCLo manageviewClo = new ViewCLo();
                addPanels(manageviewClo);

            }
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            this.label1.Text = "Rubric Form";
            if (Rubric_combo.Text == "Add")
            {
                rubrics manageAddRubPnl = new rubrics();
                addPanels(manageAddRubPnl);

            }
            if (Rubric_combo.Text == "Edit")
            {
                UpdateRubricPnl manageUpdRubPnl = new UpdateRubricPnl();
                addPanels(manageUpdRubPnl);

            }
            if (Rubric_combo.Text == "View")
            {
                ViewRubrics manageviewRub = new ViewRubrics();
                addPanels(manageviewRub);

            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void RubricLevel_combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.label1.Text = "RubricLevel Form";
            if (RubricLevel_combo.Text == "Add")
            {
                RubricLevel manageAddRubPnl = new RubricLevel();
                addPanels(manageAddRubPnl);

            }
            if (RubricLevel_combo.Text == "Edit")
            {
                EditRubLvl manageUpdRublvl = new EditRubLvl();
                addPanels(manageUpdRublvl);

            }
            if (RubricLevel_combo.Text == "View")
            {
                ViewRubLvl manageViewRublvl = new ViewRubLvl();
                addPanels(manageViewRublvl);

            }

        }

        private void att_btn_Click(object sender, EventArgs e)
        {
            this.label1.Text = "Student Attendence";
            StdAttendence manageStuAttPnl = new StdAttendence();
            addPanels(manageStuAttPnl);

        }
        private void comboBox1_SelectedIndexChanged_2(object sender, EventArgs e)
        {
            this.label1.Text = "Assessment Form";
            if (ass_combo.Text == "Add")
            {
                AssessmentPnl manageAddAss= new AssessmentPnl();
                addPanels(manageAddAss);

            }
            if (ass_combo.Text == "Edit")
            {
                EditAssPnl manageEditAss = new EditAssPnl();
                addPanels(manageEditAss);

            }
            if (ass_combo.Text == "View")
            {
                ViewAss manageViewAss = new ViewAss();
                addPanels(manageViewAss);

            }
        }

        private void comboBox1_SelectedIndexChanged_3(object sender, EventArgs e)
        {
            this.label1.Text = "Assessment Component";
            if (AssComp_combo.Text == "Add")
            {
                AddAssComponent manageAddAssComp = new AddAssComponent();
                addPanels(manageAddAssComp);

            }
            if (AssComp_combo.Text == "Edit")
            {
                EditAssComp manageEditAssComp = new EditAssComp();
                addPanels(manageEditAssComp);

            }
            if (AssComp_combo.Text == "View")
            {
                ViewAssComp manageViewAssComp = new ViewAssComp();
                addPanels(manageViewAssComp);

            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Result_Combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.label1.Text = "Student Result";
            if (Result_Combo.Text == "Edit")
            {
                Result manageStuResult = new Result();
                addPanels(manageStuResult);

            }
            if (Result_Combo.Text == "View")
            {
                ViewResult manageViewStuResult = new ViewResult();
                addPanels(manageViewStuResult);

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click_1(object sender, EventArgs e)
        {

        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            this.label1.Text = "Reports";
            reports managereport = new reports();
            addPanels(managereport);
        }
    }
}
