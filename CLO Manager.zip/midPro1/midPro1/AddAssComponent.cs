﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midPro1
{
    public partial class AddAssComponent : UserControl
    {
        public AddAssComponent()
        {
            InitializeComponent();
            LoadComponentsFromDatabase();
            FillComboBoxes();
            TodaysDate();


        }
        private void TodaysDate()
        {

            this.label5.Text = DateTime.Today.Date.ToString("yyyy-MM-dd");

        }
        private void LoadComponentsFromDatabase()
        {
            try
            {
                this.AddAssCompGrid.AllowUserToAddRows = true;
                var con = Configuration.getInstance().getConnection();
                string query = "SELECT  AC.Name,AC.TotalMarks, A.Title AssessmentName, R.Details FROM AssessmentComponent AC JOIN Assessment A ON A.Id = AC.AssessmentId JOIN Rubric R ON R.Id = AC.RubricID  WHERE A.Title NOT LIKE '%deleted%'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                this.AddAssCompGrid.DataSource = dt;
                this.AddAssCompGrid.AllowUserToAddRows = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FillComboBoxes()
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT CONCAT(R.Id,'-',R.Details) FROM Rubric R";
            SqlCommand cmd = new SqlCommand(query, con);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Rub_combo.Items.Add(reader.GetString(0));
                }
            }

            query = "SELECT CONCAT(Id,'-',Title) FROM Assessment  WHERE Title NOT LIKE '%deleted%'";
            cmd = new SqlCommand(query, con);
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Ass_combo.Items.Add(reader.GetString(0));
                }
            }
            this.Ass_combo.SelectedIndex = 0;
            this.Rub_combo.SelectedIndex = 0;
        }
        private void AddComponentIntoDataBase(string name, int totalMarks, int rubricId, int assessmentId)
        {
            // MessageBox.Show(assessmentId.ToString());
            var con = Configuration.getInstance().getConnection();
            string query = "INSERT INTO AssessmentComponent (Name,RubricId,TotalMarks,DateCreated,DateUpdated,AssessmentId) VALUES (@name,@rubricId,@totalMarks,GETDATE(),GETDATE(),@assessmentId)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@rubricId", rubricId);
            cmd.Parameters.AddWithValue("@totalMarks", totalMarks);
            cmd.Parameters.AddWithValue("@assessmentId", assessmentId);

            cmd.ExecuteNonQuery();
        }

        private int GetAssessmentComponentMarksTotal(int assId)
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT SUM(TotalMarks) FROM AssessmentComponent WHERE AssessmentId=@assId";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("assId", assId);
            if (cmd.ExecuteScalar() == null || cmd.ExecuteScalar().ToString() == "") return 0;
            return (int)cmd.ExecuteScalar();
        }

        private int GetAssessmentMarksTotal(int assId)
        {
            var con = Configuration.getInstance().getConnection();
            string query = "SELECT TotalMarks FROM Assessment WHERE Id=@assId";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("assId", assId);
            //MessageBox.Show(cmd.ExecuteScalar().ToString());
            return (int)cmd.ExecuteScalar();
        }
        private void Delete_btn_Click(object sender, EventArgs e)
        {
            try
            {
                if (Title_txt.Text == null || Title_txt.Text == "") throw new Exception("Name-less assessment component can not be created, try again");
                int totalMarks = int.Parse(Marks_txt.Value.ToString());

                int rubricId = int.Parse(Rub_combo.Text[0].ToString());
                int assessmentId = int.Parse((Ass_combo.Text.Split('-'))[0].ToString());
                if (totalMarks + GetAssessmentComponentMarksTotal(assessmentId) > GetAssessmentMarksTotal(assessmentId))
                {
                    throw new Exception("Can not add more than assessment Marks.");
                }
                AddComponentIntoDataBase(Title_txt.Text, totalMarks, rubricId, assessmentId);
                LoadComponentsFromDatabase();
                Title_txt.Text = string.Empty;
                Marks_txt.Value = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
