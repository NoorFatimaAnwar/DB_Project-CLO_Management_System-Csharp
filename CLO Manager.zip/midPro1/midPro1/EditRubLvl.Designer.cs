﻿namespace midPro1
{
    partial class EditRubLvl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Marks = new System.Windows.Forms.NumericUpDown();
            this.Details_txt = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Rubriclvl_GV = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Marks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rubriclvl_GV)).BeginInit();
            this.SuspendLayout();
            // 
            // Marks
            // 
            this.Marks.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Marks.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Marks.Location = new System.Drawing.Point(24, 195);
            this.Marks.Name = "Marks";
            this.Marks.Size = new System.Drawing.Size(203, 25);
            this.Marks.TabIndex = 25;
            // 
            // Details_txt
            // 
            this.Details_txt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Details_txt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Details_txt.Location = new System.Drawing.Point(24, 54);
            this.Details_txt.Name = "Details_txt";
            this.Details_txt.Size = new System.Drawing.Size(203, 57);
            this.Details_txt.TabIndex = 24;
            this.Details_txt.Text = "";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 34);
            this.label3.TabIndex = 23;
            this.label3.Text = "Measurement \r\nLevel";
            // 
            // Rubriclvl_GV
            // 
            this.Rubriclvl_GV.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Rubriclvl_GV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Rubriclvl_GV.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.Rubriclvl_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Rubriclvl_GV.Location = new System.Drawing.Point(253, 23);
            this.Rubriclvl_GV.Name = "Rubriclvl_GV";
            this.Rubriclvl_GV.Size = new System.Drawing.Size(398, 331);
            this.Rubriclvl_GV.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.LightSlateGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(24, 322);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 32);
            this.button1.TabIndex = 21;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "Details";
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.BackColor = System.Drawing.Color.LightSlateGray;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(152, 322);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 32);
            this.button2.TabIndex = 26;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // EditRubLvl
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Marks);
            this.Controls.Add(this.Details_txt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Rubriclvl_GV);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Name = "EditRubLvl";
            this.Size = new System.Drawing.Size(654, 376);
            ((System.ComponentModel.ISupportInitialize)(this.Marks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rubriclvl_GV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown Marks;
        private System.Windows.Forms.RichTextBox Details_txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView Rubriclvl_GV;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
    }
}
